#!/bin/bash
cat Test/secret.txt