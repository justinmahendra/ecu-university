#!/bin/bash
rm --help #list available commands for rm function