#!/bin/sh
mkdir "Task 1" "Task 2" "Task 3" #Create folders 'Task 1' 'Task 2' 'Task 3'