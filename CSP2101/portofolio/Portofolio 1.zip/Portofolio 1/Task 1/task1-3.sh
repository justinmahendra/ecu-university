#!/bin/bash
ls #List all contents of current working folder