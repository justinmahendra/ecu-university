#!/bin/bash
echo "You can only run this bash script, if you have given permission to execute"