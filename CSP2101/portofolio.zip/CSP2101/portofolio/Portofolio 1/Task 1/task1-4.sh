#!/bin/bash
chmod +x ./helloworld.sh #add execute permission to helloworld.sh