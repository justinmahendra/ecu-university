#!/bin/bash
cd $HOME #Change the directory to $HOME directory
tree # tree is used to list the directory structure